import {Entity, model, property} from '@loopback/repository';
import {Address} from './address.model';
// import {Document, model as Model } from "mongoose";

// export interface IProfile extends Document {
//   id: string;
//   name: string;
//   description: string;
//   posts: string[];
// };




@model({settings: {strict: false}})
export class Profile extends Entity {
  @property({
    type: 'string',
    id: true,
    //generated: true,
    mongodb: {dataType: 'ObjectId'}
  })
  id?: string;


  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      minLength: 10,
      maxLength: 30,
      errorMessage: 'Name should be between 10 and 30 characters.',
    //default: 'Prasannaz',
  },
})
  name: string;

  @property.array(String)
  posts: string[];


  @property.array(Address)
  // @hasMany(() => Address)
  // address: Address[];
  items: Address[];


  @property({
    type: 'string',
    default: 'prasannajob',
    required: false
  })
  description?: string;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<Profile>) {
    super(data);
  }
}

export interface ProfileRelations {
  // describe navigational properties here
}

export type ProfileWithRelations = Profile & ProfileRelations;
