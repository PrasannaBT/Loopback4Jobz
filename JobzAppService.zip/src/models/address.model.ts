import {Entity, model, property} from '@loopback/repository';

@model()
export class Address extends Entity {
  @property({
    type: 'string',
    id: true,
    //generated: true,
    mongodb: {dataType: 'ObjectId'}
  })
  id: string;


  @property({
    type: 'string',
    required: true,
  })
  addressline1: string;

  @property({
    type: 'string',
  })
  addressline2?: string;

  // @property({
  //   type: 'string',
  // })
  // profileId?: string;

  constructor(data?: Partial<Address>) {
    super(data);
  }
}

export interface AddressRelations {
  // describe navigational properties here
}

export type AddressWithRelations = Address & AddressRelations;
