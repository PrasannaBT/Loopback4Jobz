import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {JobzdbDataSource} from '../datasources';
import {UserCredentials, UserCredentialsRelations} from '../models/user-credentials.model';

export class UserCredentialsRepository extends DefaultCrudRepository<
  UserCredentials,
  typeof UserCredentials.prototype.id,
  UserCredentialsRelations
  > {
  constructor(
    @inject('datasources.Jobzdb') dataSource: JobzdbDataSource,
  ) {
    super(UserCredentials, dataSource);
  }
}
