import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {JobzdbDataSource} from '../datasources';
import {User, UserRelations} from '../models/user.model';

export type Credentials = {
  email: string;
  password: string;
  role?: string
};

// export class UserRepository extends DefaultCrudRepository<User,
//   typeof User.prototype.id,
//   UserRelations> {

//   public readonly userCredentials: HasOneRepositoryFactory<UserCredentials, typeof User.prototype.id>;

//   constructor(
//     @inject('datasources.Jobzdb') dataSource: JobzdbDataSource,
//     @repository.getter('UserCredentialsRepository')
//     protected userCredentialsRepositoryGetter: Getter<UserCredentialsRepository>,
//   ) {
//     super(User, dataSource);
//     this.userCredentials = this.createHasOneRepositoryFactoryFor('userCredentials', userCredentialsRepositoryGetter);
//     this.registerInclusionResolver('userCredentials', this.userCredentials.inclusionResolver);
//   }

//   async findCredentials(
//     userId: typeof User.prototype.id,
//   ): Promise<UserCredentials | undefined> {
//     try {
//       return await this.userCredentials(userId).get();
//     } catch (err) {
//       if (err.code === 'ENTITY_NOT_FOUND') {
//         return undefined;
//       }
//       throw err;
//     }
//   }
// }

export class UserRepository extends DefaultCrudRepository<
  User,
  typeof User.prototype.email,
  UserRelations
  > {
  constructor(
    @inject('datasources.Jobzdb') dataSource: JobzdbDataSource,
  ) {
    super(User, dataSource);
  }
}

