import {inject} from '@loopback/core';
import {DefaultCrudRepository, HasManyRepositoryFactory} from '@loopback/repository';
import {JobzdbDataSource} from '../datasources/jobzdb.datasource';
import {Address} from '../models/address.model';
import {Profile, ProfileRelations} from '../models/profile.model';
//import {AddressRepository} from './address.repository';

export class ProfileRepository extends DefaultCrudRepository<
  Profile,
  typeof Profile.prototype.id,
  ProfileRelations
  > {

  public readonly address: HasManyRepositoryFactory<Address, typeof Profile.prototype.id>;

  constructor(
    @inject('datasources.Jobzdb') dataSource: JobzdbDataSource
  ) {
    super(Profile, dataSource);

  }
}
